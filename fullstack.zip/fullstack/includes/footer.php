</main>
    <footer>
        <hr>
        <p>&copy; <?php echo date("Y"); ?> Student Portfolio System.</p>
    </footer>
</div>
</body>
</html>