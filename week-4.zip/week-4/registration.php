<?php
// Initialize variables
$errors = [];
$successMessage = "";

$name = "";
$email = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Collect and sanitize input
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirmPassword = $_POST["confirm_password"] ?? "";

    // ---------------- VALIDATION ----------------

    // Name validation
    if (empty($name)) {
        $errors["name"] = "Name is required.";
    }

    // Email validation
    if (empty($email)) {
        $errors["email"] = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors["email"] = "Invalid email format.";
    }

    // Password validation
    if (empty($password)) {
        $errors["password"] = "Password is required.";
    } elseif (strlen($password) < 8) {
        $errors["password"] = "Password must be at least 8 characters long.";
    } elseif (!preg_match("/[@$!%*?&#]/", $password)) {
        $errors["password"] = "Password must contain at least one special character.";
    }

    // Confirm password validation
    if ($password !== $confirmPassword) {
        $errors["confirm_password"] = "Passwords do not match.";
    }

    // ---------------- FILE HANDLING ----------------

    if (empty($errors)) {

        if (!file_exists("users.json")) {
            $errors["file"] = "User database file not found.";
        } else {

            $jsonData = file_get_contents("users.json");

            if ($jsonData === false) {
                $errors["file"] = "Failed to read users file.";
            } else {

                $users = json_decode($jsonData, true);

                if (!is_array($users)) {
                    $errors["file"] = "Invalid JSON format.";
                } else {

                    // Check if email already exists
                    foreach ($users as $user) {
                        if ($user["email"] === $email) {
                            $errors["email"] = "Email already registered.";
                            break;
                        }
                    }

                    if (empty($errors)) {

                        // Hash password
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                        // New user data
                        $newUser = [
                            "name" => $name,
                            "email" => $email,
                            "password" => $hashedPassword
                        ];

                        // Add user to array
                        $users[] = $newUser;

                        // Save back to JSON file
                        $result = file_put_contents(
                            "users.json",
                            json_encode($users, JSON_PRETTY_PRINT)
                        );

                        if ($result === false) {
                            $errors["file"] = "Failed to write to users file.";
                        } else {
                            $successMessage = "Registration successful!";
                            $name = "";
                            $email = "";
                        }
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Registration</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; }
        form { width: 400px; margin: 40px auto; background: white; padding: 20px; }
        label { display: block; margin-top: 10px; }
        input { width: 100%; padding: 8px; margin-top: 5px; }
        .error { color: red; font-size: 14px; }
        .success { color: green; text-align: center; margin-bottom: 10px; }
        button { margin-top: 15px; padding: 10px; width: 100%; }
    </style>
</head>
<body>

<form method="POST" action="">
    <h2>User Registration</h2>

    <?php if ($successMessage): ?>
        <div class="success"><?= $successMessage ?></div>
    <?php endif; ?>

    <label>Name</label>
    <input type="text" name="name" value="<?= htmlspecialchars($name) ?>">
    <div class="error"><?= $errors["name"] ?? "" ?></div>

    <label>Email</label>
    <input type="email" name="email" value="<?= htmlspecialchars($email) ?>">
    <div class="error"><?= $errors["email"] ?? "" ?></div>

    <label>Password</label>
    <input type="password" name="password">
    <div class="error"><?= $errors["password"] ?? "" ?></div>

    <label>Confirm Password</label>
    <input type="password" name="confirm_password">
    <div class="error"><?= $errors["confirm_password"] ?? "" ?></div>

    <div class="error"><?= $errors["file"] ?? "" ?></div>

    <button type="submit">Register</button>
</form>

</body>
</html>